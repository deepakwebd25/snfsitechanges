import * as React from 'react';
import styles from './SnfActivityTable.module.scss';

const data = [
  {
    title: 'Global Scientific Platform',
    responsible: 'Global SciComm/AIN',
    accountable: 'GMAL',
    consult: 'GMAT, PT',
    inform: 'GMAT, PT',
    links: [
      'Scientific Platform Guidance',
      'Scientific Platform Template',
      'Global Medical Content Share Site (links to SPs)'
    ]
  },
  {
    title: 'Global Scientific Narrative',
    responsible: 'Global SciComm/AIN',
    accountable: 'GMAL',
    consult: 'GMAT, PT',
    inform: 'IMD, USML'
  },
  {
    title: 'Market SKS Development',
    responsible: 'IMD, USML',
    accountable: 'IMD, USML',
    consult: 'Country Medical Leads (OUS), USMT (US), Field Leads',
    inform: 'GMAL, Global SciComm/AIN'
  },
  {
    title: 'Measurement',
    responsible: 'IMD, USML',
    accountable: 'IMD, USML',
    consult: 'Country Medical Leads (OUS), USMT (US), Field Leads',
    inform: 'MSLs, Field Directors'
  },
  {
    title: 'ALIGN Documentation',
    responsible: 'MSLs, MAs, Field Medical Excellence',
    accountable: 'MSL Leadership',
    consult: 'IMD, USML, Field Leads',
    inform: 'MSL Leadership (e.g. Field Directors)'
  }
];

const SnfActivityTable: React.FC = () => {
  const [openIndex, setOpenIndex] = React.useState<number | null>(0);

  const toggleRow = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className={styles.tableSection}>
      <div className={styles.container}>

        {/* HEADER */}
        <div className={styles.header}>
          <div></div>
          <div>Asset/Activity</div>
          <div>Responsible</div>
          <div>Accountable</div>
          <div>Consult</div>
          <div>Inform</div>
        </div>

        {/* ROWS */}
        {data.map((item, index) => (
          <div key={index}>

            {/* MAIN ROW */}
            <div className={styles.row} onClick={() => toggleRow(index)}>

             <div className={styles.activity}>
  <span
    className={`${styles.toggleIcon} ${
      openIndex === index ? styles.open : ''
    }`}
  >
    <img
      src={require(`../assets/${openIndex === index ? 'up.svg' : 'down.svg'}`)}
      className={styles.iconImg}
    />
  </span>
</div>
<div> <strong> {item.title}</strong></div>
              <div><i>{item.responsible}</i></div>
              <div><i>{item.accountable}</i></div>
              <div><i>{item.consult}</i></div>
              <div><i>{item.inform}</i></div>

            </div>

            {/* EXPAND ROW */}
            {openIndex === index && item.links && (
              <div className={styles.expandRow}>
                {item.links.map((link, i) => (
                  <a key={i} href="#" className={styles.linkBtn}>
                    {link}
                    <img src={require('../assets/arrow.svg')} />
                  </a>
                ))}
              </div>
            )}

          </div>
        ))}

      </div>
    </section>
  );
};

export default SnfActivityTable;